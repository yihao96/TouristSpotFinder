package com.alexlim.touristspotfinder.util;

public class FirestoreDict {

    // Locations
    public static final String COLL_LOCATIONS = "location";

    public static final String COLL_STATE = "state";

    public static final String COLL_LOCATION_NAME = "name";
    public static final String COLL_LOCATION_ADDRESS = "address";
    public static final String COLL_LATITUDE = "latitude";
    public static final String COLL_LONGITUDE = "longitude";
}
